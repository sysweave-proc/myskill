# v0.6.0 中文版翻译说明

本版本是在 `source-code-reading-skill-v0.6.0-merged.zip` 基础上的完整中文化版本。

## 翻译原则

1. 所有面向读者的英文自然语言均翻译为中文，并尽量保持原有规范强度、条件关系和因果关系。
2. `System`、`Subsystem`、`Path`、`Claim`、`Evidence`、`Source Anchor`、`Pattern`、`Renderer`、`Ownership`、`Lifecycle`、`Validation` 等在 Skill 中承担规范语义或机器可识别作用的术语保留英文，并在首次出现处用中文解释。
3. YAML key、程序变量、测试标识、文件路径、命令、代码、Mermaid/Graphviz 语法、源码符号和 URL 不翻译，以保证 Skill 的机器可执行性和源码导航能力不被破坏。
4. 图中的 `Start`、`Lookup`、`Use`、`Allocate` 等代码/图表标签保持原样，因为它们属于示例中的语法元素，而非正文。
5. 不改变原有目录结构、文件名、规范 ID、关系名和测试接口；本次仅进行语义等价的语言转换。

## 完整性目标

中文版本必须继续满足：

```text
原有文件资产不丢失
原有机器接口不改变
核心知识模型不改变
规范强度不降低
演进/回归机制不改变
```
